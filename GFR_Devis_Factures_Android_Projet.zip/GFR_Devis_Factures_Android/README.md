# GFR Devis & Factures — projet Android

Cette application Android encapsule le fichier HTML fourni dans une WebView locale.
L'interface, le logo intégré, les prestations, les champs, les calculs HT/TVA/TTC,
la sauvegarde locale et le chargement du document restent ceux du fichier d'origine.
Le bouton PDF ouvre la boîte d'impression Android (où l'utilisateur peut choisir
« Enregistrer au format PDF »).

## Construire l'APK
1. Installer Android Studio et le SDK Android 35.
2. Ouvrir le dossier `GFR_Devis_Factures_Android` dans Android Studio.
3. Laisser Gradle synchroniser le projet.
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK de débogage sera généré dans `app/build/outputs/apk/debug/app-debug.apk`.

Pour installer sur le téléphone, transférer l'APK et autoriser temporairement
l'installation depuis cette source si Android le demande.

## Notes
- L'application fonctionne hors ligne : aucun serveur ni permission Internet n'est requis.
- La sauvegarde utilise le stockage local du WebView sur cet appareil.
- Le bouton PDF s'appuie sur le service d'impression Android.
- Ce dossier est le projet source; l'APK n'a pas été compilé dans cet environnement,
  car le SDK Android / Android Studio n'y est pas installé.
